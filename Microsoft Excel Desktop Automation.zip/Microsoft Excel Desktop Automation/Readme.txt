1.Install Ranorex Studio (but I have a trial version only)
https://www.ranorex.com/free-trial/

2.Open the project "Microsoft Excel Desktop Automation"

3.Click the run button and verify the test results after executing the testsuite.